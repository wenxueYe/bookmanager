import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Index from '../views/index.vue'

import PageOne from '../views/PageOne'
import PageTwo from '../views/PageTwo'
import PageThree from '../views/PageThree'
import PageFour from '../views/PageFour'

Vue.use(VueRouter)

const routes = [
    {
        path: '/index',
        name: '图书管理',
        show: true,
        redirect: "/pageOne",
        component: Index,
        children: [
            {
                show: true,
                path: '/pageOne',
                name: '管理图书',
                component: PageOne
            }
            ,
            {
                show: true,
                path: '/pageTwo',
                name: '添加新书',
                component: PageTwo
            },

            {
                path: '/pageThree',
                show: false,
                component: PageThree
            }

        ]
    },

    {
        path: '/about',
        name: 'About',
        show: false,
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
    }

]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
