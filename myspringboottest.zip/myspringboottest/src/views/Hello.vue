<template>
    <div class="hello">
        <h1>This is an Hello page</h1>

        <table>
            <tr>
                <td>编号</td>
                <td>图书名称</td>
                <td>作者</td>
            </tr>
            <tr v-for="item in book">
                <td>{{item.id}}</td>
                <td>{{item.name}}</td>
                <td>{{item.author}}</td>
            </tr>
        </table>

        <el-switch
                v-model="value"
                active-color="#13ce66"
                inactive-color="#ff4949">
        </el-switch>

    </div>
</template>




<script>
    export default {
        data() {
            return {
                value: true,
                message: "zhangsan",
                book:[
                    {
                        "id": 1,
                        "name": "解忧杂货店",
                        "author": "东野圭吾"
                    }
                    // ,
                    // {
                    //     "id": 2,
                    //     "name": "追风筝的人",
                    //     "author": "卡勒德·胡赛尼"
                    // },
                    // {
                    //     "id": 3,
                    //     "name": "人间失格",
                    //     "author": "太宰治"
                    // },
                    // {
                    //     "id": 4,
                    //     "name": "这就是二十四节气",
                    //     "author": "高春香"
                    // },
                    // {
                    //     "id": 5,
                    //     "name": "白夜行",
                    //     "author": "东野圭吾"
                    // },
                    // {
                    //     "id": 6,
                    //     "name": "摆渡人",
                    //     "author": "克莱儿·麦克福尔"
                    // },
                    // {
                    //     "id": 7,
                    //     "name": "暖暖心绘本",
                    //     "author": "米拦弗特毕"
                    // },
                    // {
                    //     "id": 8,
                    //     "name": "天才在左疯子在右",
                    //     "author": "高铭"
                    // },
                    // {
                    //     "id": 9,
                    //     "name": "我们仨",
                    //     "author": "杨绛"
                    // },
                    // {
                    //     "id": 10,
                    //     "name": "活着",
                    //     "author": "余华"
                    // },
                    // {
                    //     "id": 11,
                    //     "name": "水浒传",
                    //     "author": "施耐庵"
                    // },
                    // {
                    //     "id": 12,
                    //     "name": "三国演义",
                    //     "author": "罗贯中"
                    // },
                    // {
                    //     "id": 13,
                    //     "name": "红楼梦",
                    //     "author": "曹雪芹"
                    // },
                    // {
                    //     "id": 14,
                    //     "name": "西游记",
                    //     "author": "吴承恩"
                    // }
                ]

            }
        },
        created() {
            const _this = this
            axios.get("http://localhost:8888/book/findAll").then(function (resp) {
                console.log(resp)
                _this.book = resp.data

            })
            // const _this = this
            // axios.get('http://localhost:8181/book/findAll/'+(currentPage-1)+'/6').then(function(resp){
            //     console.log(resp)
            //     _this.tableData = resp.data.content
            //     _this.pageSize = resp.data.size
            //     _this.total = resp.data.totalElements
            // })
        }

    }
</script>


<style>

</style>