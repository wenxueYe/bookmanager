<template>
    <div>
        <el-container style="height: 600px; border: 1px solid #eee">
            <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
                <el-menu :default-openeds="['0']" router>
                    <el-submenu v-for="(item,index) in $router.options.routes" :index="index+''" v-if="item.show">
                        <template slot="title"><i class="el-icon-setting"></i>{{item.name}}</template>
                        <el-menu-item v-for="(subitem,index) in item.children" :index="subitem.path"
                                      :class="$route.path==subitem.path?'is-active':''"
                                      v-if="subitem.show"
                        >
                            {{subitem.name}}
                        </el-menu-item>
                    </el-submenu>
                </el-menu>
            </el-aside>

            <el-container>
                <el-header style="text-align: right; font-size: 12px">
                    <el-dropdown>
                        <i class="el-icon-setting" style="margin-right: 15px"></i>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item>退出</el-dropdown-item>
                            <el-dropdown-item>切换账号</el-dropdown-item>
                            <el-dropdown-item>修改密码</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                    <span>冶文学</span>
                </el-header>

                <el-main>
                    <router-view></router-view>
                </el-main>
            </el-container>
        </el-container>
    </div>
</template>
